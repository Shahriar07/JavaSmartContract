
var requestTypePost = 'POST';
var url = 'http://10.88.250.129:8090';

var popupContainer;
var redeemButton;
var popupButton;
var popupImage;
var popupLabelMsg;
var popupLabelResult;

var submitRedeem = function() {
    var request = new XMLHttpRequest();
    request.open(requestTypePost, url, true);

    request.setRequestHeader("Content-Type", "application/json");
    request.setRequestHeader("Accept", "application/json");

    var scratchNo = document.getElementById("voucherId").value;

    console.log("Voucher id " + scratchNo);

    var requestData = {
        "HeadNo":"8560",
        "ScratchNo":scratchNo,
        "TxAmount":"100"
    };

    console.log("Request json : " + requestData.toString());

    request.send(JSON.stringify(requestData));

    console.log("Request sent.")

    request.onload = function () {
        if (request.status !== 200) {
            console.log("Server error" + request.status);
            showErrorPopUp();

            return;
        }

        console.log("Response received : " + request.responseText);
        var resopnseObject = JSON.parse(request.responseText);
        console.log("Response received : " + resopnseObject);

        if (resopnseObject["ResultCode"] === "1111") {
            showSuccessPopUp();
        } else {
            showErrorPopUp();
        }
    };
};

var showSuccessPopUp = function() {
    console.log("Submit button clicked.");
    popupContainer.style.display = "block";
    popupImage.src = "resource/img_success.png";
    popupLabelResult.innerText = 'SUCCESS';
    popupLabelMsg.innerText = 'You have successfully redeemed your code.';
};

var showErrorPopUp = function() {
    console.log("Submit button clicked.");
    popupContainer.style.display = "block";
    popupImage.src = "resource/img_error.png";
    popupLabelResult.innerText = 'ERROR';
    popupLabelMsg.innerText = 'The code you entered is invalid. \n Please enter a correct one.';
};

window.onload = function () {

    console.log("Onload");
    popupContainer = document.getElementById("popup-container");
    redeemButton = document.getElementById("redeem-button");
    popupButton = document.getElementById("popup-button");
    popupImage = document.getElementById("popup-img");
    popupLabelResult = document.getElementById("popup-label-result");
    popupLabelMsg = document.getElementById("popup-label-msg");


    popupButton.onclick = function() {
        popupContainer.style.display = "none"
    }
};

